<div <?php echo e($attributes->merge($getExtraAttributes())); ?>>
    <?php echo e($getChildComponentContainer()); ?>

</div>
<?php /**PATH /opt/lampp/htdocs/Laravel-blog/vendor/filament/forms/src/../resources/views/components/grid.blade.php ENDPATH**/ ?>