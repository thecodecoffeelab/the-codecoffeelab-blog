<td
    <?php echo e($attributes->class([
        'filament-tables-cell',
        'dark:text-white' => config('tables.dark_mode'),
    ])); ?>

>
    <?php echo e($slot); ?>

</td>
<?php /**PATH /opt/lampp/htdocs/Laravel-blog/vendor/filament/tables/src/../resources/views/components/cell.blade.php ENDPATH**/ ?>