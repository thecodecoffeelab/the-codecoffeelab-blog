
<?php /**PATH /opt/lampp/htdocs/Laravel-blog/vendor/filament/filament/src/../resources/views/components/layouts/app/sidebar/footer.blade.php ENDPATH**/ ?>